export const navLinks = [
    {
        path: '/services',
        text: 'Services',
    },
    {
        path: '/platforms/shopify',
        text: 'Platforms',
    },
    {
        path: '/industries',
        text: 'Industries',
    },
    {
        path: '/our-work',
        text: 'Our Work',
    },
    {
        path: '/process',
        text: 'Process',
    },
    {
        path: '/contact-us',
        text: 'Contact',
    }
]